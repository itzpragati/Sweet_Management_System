import { useState, useMemo } from "react";
import { useSweets } from "@/lib/mock-data";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Filter, ShoppingBag } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Shop() {
  const { sweets, categories: contextCategories, purchaseSweet } = useSweets();
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState<string>("all");
  const [priceRange, setPriceRange] = useState([0, 2000]);

  const filteredSweets = useMemo(() => {
    return sweets.filter((sweet) => {
      const matchesSearch = sweet.name.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = category === "all" || sweet.category === category;
      const matchesPrice = sweet.price >= priceRange[0] && sweet.price <= priceRange[1];
      return matchesSearch && matchesCategory && matchesPrice;
    });
  }, [sweets, search, category, priceRange]);

  const categories = ["all", ...contextCategories];

  return (
    <div className="container py-12">
      <div className="flex flex-col md:flex-row justify-between items-end mb-8 gap-4">
        <div>
          <h1 className="text-4xl font-bold mb-2">Our Menu</h1>
          <p className="text-muted-foreground">Freshly made treats for every occasion.</p>
        </div>
        
        <div className="flex items-center gap-2 w-full md:w-auto">
          <div className="relative w-full md:w-80">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Search sweets..." 
              className="pl-9 rounded-full bg-muted/50 border-transparent focus:bg-background transition-all"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Filters Sidebar */}
        <div className="w-full lg:w-64 space-y-8 h-fit lg:sticky lg:top-24">
          <div>
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <Filter className="h-4 w-4" /> Categories
            </h3>
            <div className="flex flex-wrap lg:flex-col gap-2">
              {categories.map((cat) => (
                <Button
                  key={cat}
                  variant={category === cat ? "default" : "ghost"}
                  onClick={() => setCategory(cat)}
                  className={`justify-start rounded-full capitalize ${category === cat ? "" : "text-muted-foreground hover:text-foreground"}`}
                >
                  {cat}
                </Button>
              ))}
            </div>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Price Range</h3>
            <Slider
              defaultValue={[0, 2000]}
              max={2000}
              step={50}
              value={priceRange}
              onValueChange={setPriceRange}
              className="mb-4"
            />
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>₹{priceRange[0]}</span>
              <span>₹{priceRange[1]}</span>
            </div>
          </div>
        </div>

        {/* Product Grid */}
        <div className="flex-1">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            <AnimatePresence mode="popLayout">
              {filteredSweets.map((sweet) => (
                <motion.div
                  key={sweet.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.2 }}
                >
                  <Card className="h-full flex flex-col overflow-hidden border-none shadow-sm hover:shadow-lg transition-all duration-300">
                    <div className="relative aspect-[4/3] bg-muted overflow-hidden">
                      <img
                        src={sweet.image}
                        alt={sweet.name}
                        className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                      />
                      {sweet.quantity === 0 && (
                        <div className="absolute inset-0 bg-black/50 flex items-center justify-center backdrop-blur-[2px]">
                          <span className="text-white font-bold text-lg border-2 border-white px-4 py-2 rounded-full transform -rotate-12">SOLD OUT</span>
                        </div>
                      )}
                      <Badge className="absolute bottom-3 left-3 bg-white/90 text-foreground backdrop-blur-sm">
                        {sweet.category}
                      </Badge>
                    </div>
                    
                    <CardContent className="p-5 flex-1">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="font-bold text-lg leading-tight">{sweet.name}</h3>
                        <span className="font-bold text-lg text-primary">₹{sweet.price.toFixed(2)}</span>
                      </div>
                      <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{sweet.description}</p>
                      
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <div className={`h-2 w-2 rounded-full ${sweet.quantity > 10 ? 'bg-green-500' : sweet.quantity > 0 ? 'bg-yellow-500' : 'bg-red-500'}`} />
                        {sweet.quantity > 0 ? `${sweet.quantity} in stock` : 'Out of stock'}
                      </div>
                    </CardContent>

                    <CardFooter className="p-5 pt-0">
                      <Button 
                        className="w-full rounded-full" 
                        disabled={sweet.quantity === 0}
                        onClick={() => purchaseSweet(sweet.id)}
                      >
                        <ShoppingBag className="mr-2 h-4 w-4" />
                        {sweet.quantity === 0 ? "Unavailable" : "Purchase"}
                      </Button>
                    </CardFooter>
                  </Card>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
          
          {filteredSweets.length === 0 && (
            <div className="text-center py-20 text-muted-foreground">
              <p className="text-lg">No sweets found matching your criteria.</p>
              <Button variant="link" onClick={() => {setCategory("all"); setSearch(""); setPriceRange([0,2000])}}>
                Clear all filters
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
