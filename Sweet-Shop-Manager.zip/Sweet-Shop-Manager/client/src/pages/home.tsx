import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { motion } from "framer-motion";
import heroImg from "@assets/generated_images/modern_bright_sweet_shop_hero_background.png";
import { useSweets } from "@/lib/mock-data";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Star } from "lucide-react";

export default function Home() {
  const { sweets } = useSweets();
  const featuredSweets = sweets.slice(0, 3);

  return (
    <div className="flex flex-col gap-16 pb-16">
      {/* Hero Section */}
      <section className="relative h-[600px] w-full overflow-hidden flex items-center">
        <div className="absolute inset-0 z-0">
          <img
            src={heroImg}
            alt="Sweet Shop"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/20" />
        </div>
        
        <div className="container relative z-10 text-white">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-2xl"
          >
            <h1 className="text-5xl md:text-7xl font-bold mb-6 drop-shadow-lg leading-tight">
              Life is Short, <br/>
              <span className="text-primary-foreground">Make it Sweet.</span>
            </h1>
            <p className="text-lg md:text-xl mb-8 opacity-90 max-w-lg drop-shadow-md font-medium">
              Discover our handcrafted collection of chocolates, pastries, and candies made with love and the finest ingredients.
            </p>
            <Link href="/shop">
              <Button size="lg" className="rounded-full text-lg px-8 py-6 bg-primary hover:bg-primary/90 hover:scale-105 transition-all duration-300 shadow-xl">
                Shop Now <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Featured Section */}
      <section className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4 text-primary">Featured Treats</h2>
          <p className="text-muted-foreground max-w-md mx-auto">
            Our most popular selections, curated just for you. Get them while they last!
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {featuredSweets.map((sweet, i) => (
            <motion.div
              key={sweet.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="overflow-hidden border-none shadow-lg hover:shadow-xl transition-shadow duration-300 group h-full flex flex-col">
                <div className="relative aspect-square overflow-hidden bg-muted">
                  <img
                    src={sweet.image}
                    alt={sweet.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <Badge className="absolute top-4 right-4 bg-white/90 text-foreground hover:bg-white backdrop-blur-sm shadow-sm">
                    ₹{sweet.price.toFixed(2)}
                  </Badge>
                </div>
                <CardContent className="p-6 flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold tracking-wider uppercase text-primary/80">{sweet.category}</span>
                    <div className="flex items-center text-yellow-400 text-xs">
                      <Star className="h-3 w-3 fill-current" />
                      <Star className="h-3 w-3 fill-current" />
                      <Star className="h-3 w-3 fill-current" />
                      <Star className="h-3 w-3 fill-current" />
                      <Star className="h-3 w-3 fill-current" />
                    </div>
                  </div>
                  <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors">{sweet.name}</h3>
                  <p className="text-muted-foreground text-sm line-clamp-2">{sweet.description}</p>
                </CardContent>
                <CardFooter className="p-6 pt-0">
                  <Link href="/shop" className="w-full">
                    <Button variant="secondary" className="w-full rounded-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                      View Details
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Newsletter / CTA */}
      <section className="container mb-16">
        <div className="bg-accent/30 rounded-3xl p-12 text-center relative overflow-hidden">
          <div className="absolute top-0 right-0 -mt-10 -mr-10 w-40 h-40 bg-primary/10 rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 left-0 -mb-10 -ml-10 w-40 h-40 bg-primary/10 rounded-full blur-3xl"></div>
          
          <h2 className="text-3xl font-bold mb-4">Join the Sweet Club</h2>
          <p className="text-muted-foreground mb-8 max-w-lg mx-auto">
            Subscribe to get updates on new arrivals, special offers, and a little sweetness in your inbox.
          </p>
          <div className="flex max-w-md mx-auto gap-2">
             <input 
              type="email" 
              placeholder="Enter your email" 
              className="flex-1 h-12 rounded-full border border-input bg-background px-4 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
            />
            <Button size="lg" className="rounded-full px-8">Subscribe</Button>
          </div>
        </div>
      </section>
    </div>
  );
}
