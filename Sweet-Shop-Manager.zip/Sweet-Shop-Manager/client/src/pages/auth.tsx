import { useState } from "react";
import { useAuth } from "@/lib/mock-data";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Candy } from "lucide-react";

export default function Auth() {
  const { login, register } = useAuth();
  const [, setLocation] = useLocation();
  const [username, setUsername] = useState("");
  const [role, setRole] = useState<"admin" | "user">("user");
  
  // Register state
  const [regUsername, setRegUsername] = useState("");
  const [regRole, setRegRole] = useState<"admin" | "user">("user");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    login(username, role);
    setLocation("/");
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    register(regUsername, regRole);
    setLocation("/");
  };

  return (
    <div className="container min-h-[calc(100vh-4rem)] flex items-center justify-center py-12">
      <Card className="w-full max-w-md border-none shadow-2xl overflow-hidden">
        <div className="h-2 bg-primary w-full" />
        <CardHeader className="text-center pb-2">
          <div className="mx-auto bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mb-4 text-primary">
            <Candy className="h-8 w-8" />
          </div>
          <CardTitle className="text-2xl">Welcome to Sweet Tooth</CardTitle>
          <CardDescription>Sign in to manage your account</CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="login">Login</TabsTrigger>
              <TabsTrigger value="register">Register</TabsTrigger>
            </TabsList>
            
            <TabsContent value="login">
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="username">Username</Label>
                  <Input 
                    id="username" 
                    placeholder="Enter your username" 
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                    className="rounded-lg"
                  />
                </div>
                
                <div className="space-y-2">
                   <Label>Role (Simulation)</Label>
                   <div className="flex gap-2">
                      <Button 
                        type="button" 
                        variant={role === "user" ? "default" : "outline"}
                        className="flex-1"
                        onClick={() => setRole("user")}
                      >
                        Customer
                      </Button>
                      <Button 
                        type="button" 
                        variant={role === "admin" ? "default" : "outline"}
                        className="flex-1"
                        onClick={() => setRole("admin")}
                      >
                        Admin
                      </Button>
                   </div>
                   <p className="text-xs text-muted-foreground mt-1">
                     * Select "Admin" to access the inventory dashboard.
                   </p>
                </div>

                <Button type="submit" className="w-full rounded-full mt-4" size="lg">
                  Sign In
                </Button>
              </form>
            </TabsContent>
            
            <TabsContent value="register">
              <form onSubmit={handleRegister} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="reg-username">Choose Username</Label>
                  <Input 
                    id="reg-username" 
                    placeholder="Choose a username" 
                    value={regUsername}
                    onChange={(e) => setRegUsername(e.target.value)}
                    required
                    className="rounded-lg"
                  />
                </div>
                
                <div className="space-y-2">
                   <Label>Select Role</Label>
                   <div className="flex gap-2">
                      <Button 
                        type="button" 
                        variant={regRole === "user" ? "default" : "outline"}
                        className="flex-1"
                        onClick={() => setRegRole("user")}
                      >
                        Customer
                      </Button>
                      <Button 
                        type="button" 
                        variant={regRole === "admin" ? "default" : "outline"}
                        className="flex-1"
                        onClick={() => setRegRole("admin")}
                      >
                        Admin
                      </Button>
                   </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email (Optional)</Label>
                  <Input 
                    id="email" 
                    type="email"
                    placeholder="Enter your email" 
                    className="rounded-lg"
                  />
                </div>

                <Button type="submit" className="w-full rounded-full mt-4" size="lg">
                  Create Account
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
