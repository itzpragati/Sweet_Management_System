import { useState, useEffect, createContext, useContext, ReactNode } from "react";
import { useToast } from "@/hooks/use-toast";
import truffleImg from "@assets/generated_images/gourmet_chocolate_truffles.png";
import macaronImg from "@assets/generated_images/colorful_macarons.png";
import gummyImg from "@assets/generated_images/fruit_gummy_candies.png";
import cheesecakeImg from "@assets/generated_images/strawberry_cheesecake.png";

export interface Sweet {
  id: string;
  name: string;
  category: string;
  price: number;
  quantity: number;
  image: string;
  description: string;
}

export interface User {
  id: string;
  username: string;
  role: "admin" | "user";
}

const INITIAL_CATEGORIES = ["chocolates", "candies", "pastries", "cakes"];

const INITIAL_SWEETS: Sweet[] = [
  {
    id: "1",
    name: "Gourmet Dark Truffles",
    category: "chocolates",
    price: 899,
    quantity: 50,
    image: truffleImg,
    description: "Rich dark chocolate truffles dusted with cocoa powder.",
  },
  {
    id: "2",
    name: "Rainbow Macarons",
    category: "pastries",
    price: 1250,
    quantity: 30,
    image: macaronImg,
    description: "Assortment of delicate french macarons in various flavors.",
  },
  {
    id: "3",
    name: "Fruit Gummy Mix",
    category: "candies",
    price: 299,
    quantity: 100,
    image: gummyImg,
    description: "A colorful mix of fruit-flavored gummy bears and worms.",
  },
  {
    id: "4",
    name: "Strawberry Cheesecake",
    category: "cakes",
    price: 450,
    quantity: 12,
    image: cheesecakeImg,
    description: "Classic New York style cheesecake with fresh strawberry topping.",
  },
];

// --- Contexts ---

interface SweetContextType {
  sweets: Sweet[];
  categories: string[];
  addSweet: (sweet: Omit<Sweet, "id">) => void;
  updateSweet: (id: string, sweet: Partial<Sweet>) => void;
  deleteSweet: (id: string) => void;
  purchaseSweet: (id: string) => void;
  restockSweet: (id: string, amount: number) => void;
  addCategory: (category: string) => void;
}

const SweetContext = createContext<SweetContextType | undefined>(undefined);

export function SweetProvider({ children }: { children: ReactNode }) {
  const [sweets, setSweets] = useState<Sweet[]>(INITIAL_SWEETS);
  const [categories, setCategories] = useState<string[]>(INITIAL_CATEGORIES);
  const { toast } = useToast();

  const addCategory = (category: string) => {
    if (!categories.includes(category.toLowerCase())) {
      setCategories(prev => [...prev, category.toLowerCase()]);
      toast({ title: "Category Added", description: `${category} has been added.` });
    }
  };

  const addSweet = (sweet: Omit<Sweet, "id">) => {
    const newSweet = { ...sweet, id: Math.random().toString(36).substr(2, 9) };
    setSweets((prev) => [...prev, newSweet]);
    toast({ title: "Sweet Added", description: `${newSweet.name} has been added to inventory.` });
  };

  const updateSweet = (id: string, updates: Partial<Sweet>) => {
    setSweets((prev) => prev.map((s) => (s.id === id ? { ...s, ...updates } : s)));
    toast({ title: "Sweet Updated", description: "Product details have been updated." });
  };

  const deleteSweet = (id: string) => {
    setSweets((prev) => prev.filter((s) => s.id !== id));
    toast({ title: "Sweet Deleted", description: "Product has been removed from inventory.", variant: "destructive" });
  };

  const purchaseSweet = (id: string) => {
    setSweets((prev) =>
      prev.map((s) => {
        if (s.id === id) {
          if (s.quantity > 0) {
            toast({ title: "Purchase Successful!", description: `Enjoy your ${s.name}!` });
            return { ...s, quantity: s.quantity - 1 };
          } else {
             toast({ title: "Out of Stock", description: "Sorry, this item is unavailable.", variant: "destructive" });
             return s;
          }
        }
        return s;
      })
    );
  };

  const restockSweet = (id: string, amount: number) => {
      setSweets((prev) =>
      prev.map((s) => (s.id === id ? { ...s, quantity: s.quantity + amount } : s))
    );
    toast({ title: "Restocked", description: "Inventory updated." });
  }

  return (
    <SweetContext.Provider value={{ sweets, categories, addSweet, updateSweet, deleteSweet, purchaseSweet, restockSweet, addCategory }}>
      {children}
    </SweetContext.Provider>
  );
}

export function useSweets() {
  const context = useContext(SweetContext);
  if (!context) throw new Error("useSweets must be used within a SweetProvider");
  return context;
}

// --- Auth Context ---

interface AuthContextType {
  user: User | null;
  login: (username: string, role: "admin" | "user") => void;
  register: (username: string, role: "admin" | "user") => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const { toast } = useToast();

  const login = (username: string, role: "admin" | "user") => {
    setUser({ id: "123", username, role });
    toast({ title: `Welcome back, ${username}!`, description: `You are logged in as ${role}.` });
  };

  const register = (username: string, role: "admin" | "user") => {
    setUser({ id: Math.random().toString(36).substr(2, 9), username, role });
    toast({ title: `Welcome to Sweet Tooth, ${username}!`, description: "Your account has been created successfully." });
  };

  const logout = () => {
    setUser(null);
    toast({ title: "Logged out", description: "See you soon!" });
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used within a AuthProvider");
  return context;
}
